


Name:

-----------------------------------------------

Please confirm that you compiled your solution with test cases exercising ALL
functions using g++ -std=c++11.  Confirm this statement by typing YES below.
(If you did not do this, compilation errors may result in an overall grade of
zero!)






Describe what augmentations to the bst data structures you made to complete the 
project -- i.e., what types / data members did you change and why?







-----------------------------------------------
Which functions did you need to modify as a result of the augmentations from the previous
question?  









-----------------------------------------------
For each function from the previous question, how did you ensure that the (assymptotic) runtime 
remained the same?








-----------------------------------------------
For each of the assigned functions, tell us how far you got using the choices 0-5 and
answer the given questions.  


0:  didn't get started
1:  started, but far from working
2:  have implementation but only works for simple cases
3:  finished and I think it works most of the time but not sure the runtime req is met. 
4:  finished and I think it works most of the time and I'm sure my design leads to 
       the correct runtime (even if I still have a few bugs).
5:  finished and confident on correctness and runtime requirements


to_vector level of completion:  ___________  


-----------------------------------------------
get_ith level of completion:  ___________  

    How did you ensure O(h) runtime?

    ANSWER:

-----------------------------------------------
num_geq level of completion:  ___________  

    How did you ensure O(h) runtime?

    ANSWER:

-----------------------------------------------
num_leq level of completion:  ____________

    How did you ensure O(h) runtime?

    ANSWER:

-----------------------------------------------
num_range level of completion:  ____________

    How did you ensure O(h) runtime?

    ANSWER:

-----------------------------------------------
Implementation of size-balanced criteria according to 
the given guidelines (including bst_sb_work):

    Level of completion: ___________


Write a few sentences describing how you tested your solutions.  Are there
any tests that in retrospect you wish you'd done?











